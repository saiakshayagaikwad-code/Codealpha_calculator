#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define FILE_NAME "students.dat"
#define NAME_LEN 50

typedef struct {
    int id;
    char name[NAME_LEN];
    float marks;
} Student;

void addStudent(void)
{
    FILE *fp = fopen(FILE_NAME, "ab");
    Student s;
    if (!fp) { perror("File error"); return; }

    printf("Enter student ID: ");
    scanf("%d", &s.id);
    printf("Enter student name: ");
    scanf(" %49[^\n]", s.name);
    printf("Enter marks: ");
    scanf("%f", &s.marks);

    fwrite(&s, sizeof(Student), 1, fp);
    fclose(fp);
    printf("Student added successfully.\n");
}

void displayStudents(void)
{
    FILE *fp = fopen(FILE_NAME, "rb");
    Student s;
    if (!fp) { printf("No student records found.\n"); return; }

    printf("\nID\tName\t\tMarks\n");
    printf("--------------------------------\n");
    while (fread(&s, sizeof(Student), 1, fp) == 1)
        printf("%d\t%-16s%.2f\n", s.id, s.name, s.marks);
    fclose(fp);
}

void searchStudent(void)
{
    FILE *fp = fopen(FILE_NAME, "rb");
    Student s;
    int id, found = 0;
    if (!fp) { printf("No student records found.\n"); return; }

    printf("Enter student ID to search: ");
    scanf("%d", &id);
    while (fread(&s, sizeof(Student), 1, fp) == 1)
    {
        if (s.id == id)
        {
            printf("ID: %d\nName: %s\nMarks: %.2f\n", s.id, s.name, s.marks);
            found = 1;
            break;
        }
    }
    fclose(fp);
    if (!found) printf("Student not found.\n");
}

void updateStudent(void)
{
    FILE *fp = fopen(FILE_NAME, "rb+");
    Student s;
    int id, found = 0;
    if (!fp) { printf("No student records found.\n"); return; }

    printf("Enter student ID to update: ");
    scanf("%d", &id);
    while (fread(&s, sizeof(Student), 1, fp) == 1)
    {
        if (s.id == id)
        {
            printf("Enter new name: ");
            scanf(" %49[^\n]", s.name);
            printf("Enter new marks: ");
            scanf("%f", &s.marks);
            fseek(fp, -(long)sizeof(Student), SEEK_CUR);
            fwrite(&s, sizeof(Student), 1, fp);
            found = 1;
            break;
        }
    }
    fclose(fp);
    printf(found ? "Student updated successfully.\n" : "Student not found.\n");
}

void deleteStudent(void)
{
    FILE *fp = fopen(FILE_NAME, "rb");
    FILE *temp = fopen("temp.dat", "wb");
    Student s;
    int id, found = 0;
    if (!fp || !temp) { printf("File error.\n"); if (fp) fclose(fp); if (temp) fclose(temp); return; }

    printf("Enter student ID to delete: ");
    scanf("%d", &id);
    while (fread(&s, sizeof(Student), 1, fp) == 1)
    {
        if (s.id == id) found = 1;
        else fwrite(&s, sizeof(Student), 1, temp);
    }
    fclose(fp);
    fclose(temp);
    remove(FILE_NAME);
    rename("temp.dat", FILE_NAME);
    printf(found ? "Student deleted successfully.\n" : "Student not found.\n");
}

int main(void)
{
    int choice;
    do
    {
        printf("\n===== STUDENT MANAGEMENT SYSTEM =====\n");
        printf("1. Add Student\n2. Display Students\n3. Search Student\n4. Update Student\n5. Delete Student\n6. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);
        switch (choice)
        {
            case 1: addStudent(); break;
            case 2: displayStudents(); break;
            case 3: searchStudent(); break;
            case 4: updateStudent(); break;
            case 5: deleteStudent(); break;
            case 6: printf("Exiting...\n"); break;
            default: printf("Invalid choice.\n");
        }
    } while (choice != 6);
    return 0;
}
