#include <stdio.h>

#define MAX 10

void readMatrix(int a[MAX][MAX], int rows, int cols)
{
    int i, j;
    for (i = 0; i < rows; i++)
        for (j = 0; j < cols; j++)
            scanf("%d", &a[i][j]);
}

void printMatrix(int a[MAX][MAX], int rows, int cols)
{
    int i, j;
    for (i = 0; i < rows; i++)
    {
        for (j = 0; j < cols; j++)
            printf("%d ", a[i][j]);
        printf("\n");
    }
}

void addMatrix(int a[MAX][MAX], int b[MAX][MAX], int r, int c)
{
    int i, j;
    printf("Matrix Addition:\n");
    for (i = 0; i < r; i++)
    {
        for (j = 0; j < c; j++)
            printf("%d ", a[i][j] + b[i][j]);
        printf("\n");
    }
}

void multiplyMatrix(int a[MAX][MAX], int b[MAX][MAX], int r1, int c1, int c2)
{
    int i, j, k, sum;
    printf("Matrix Multiplication:\n");
    for (i = 0; i < r1; i++)
    {
        for (j = 0; j < c2; j++)
        {
            sum = 0;
            for (k = 0; k < c1; k++)
                sum += a[i][k] * b[k][j];
            printf("%d ", sum);
        }
        printf("\n");
    }
}

void transpose(int a[MAX][MAX], int rows, int cols)
{
    int i, j;
    printf("Transpose:\n");
    for (j = 0; j < cols; j++)
    {
        for (i = 0; i < rows; i++)
            printf("%d ", a[i][j]);
        printf("\n");
    }
}

int main(void)
{
    int a[MAX][MAX], b[MAX][MAX];
    int r1, c1, r2, c2;

    printf("Enter rows and columns of Matrix A: ");
    scanf("%d %d", &r1, &c1);
    printf("Enter Matrix A elements:\n");
    readMatrix(a, r1, c1);

    printf("Enter rows and columns of Matrix B: ");
    scanf("%d %d", &r2, &c2);
    printf("Enter Matrix B elements:\n");
    readMatrix(b, r2, c2);

    if (r1 == r2 && c1 == c2)
        addMatrix(a, b, r1, c1);
    else
        printf("Addition requires equal dimensions.\n");

    if (c1 == r2)
        multiplyMatrix(a, b, r1, c1, c2);
    else
        printf("Multiplication dimensions are incompatible.\n");

    transpose(a, r1, c1);
    return 0;
}
