CodeAlpha C Programming Internship - Tasks 1, 2 and 3

Completed projects:
1. Basic Calculator Program - calculator.c
2. Matrix Operations - matrix_operations.c
3. Student Management System - student_management.c

Each program is written in standard C and is intended to be uploaded to a public GitHub repository.

Suggested repository names:
CodeAlpha_Calculator
CodeAlpha_MatrixOperations
CodeAlpha_StudentManagement

Important:
GitHub links cannot be created from this folder because GitHub login/upload must be done from the user's account. Use the included .c files to create the repositories and then paste the resulting URLs into the CodeAlpha submission form.
